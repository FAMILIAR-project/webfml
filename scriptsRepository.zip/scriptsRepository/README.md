Repository of FAMILIAR scripts 
======

A collection of FAMILIAR scripts:
 * for testing your installation 
 * for reproducing presentations or papers' examples
 * for illustrating the manual
 * ... 
 
